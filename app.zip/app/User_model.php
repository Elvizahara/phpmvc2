<?php 

class User_model {
    private $nama = ' Maulida Handayani';

    public function getUser()
    {
        return $this->nama;
    }
}